#USM1-Assgn-17

def validate_name(name):
    #Start writing your code here
    if(name!="" and len(name)<=15 and name.isalpha()):
        return True
    else:
        return False
        
def validate_phone_no(phno):
    #Start writing your code here
    if(len(phno)==10 and phno.isdigit()):
        if (phno.count(phno[0])==10):
            return False
        else:
            return True
    else:
        return False

def validate_email_id(email_id):
    #Start writing your code here
    if (email_id.count('@')==1 and email_id[-4:]==".com"):
        ind_at=email_id.index('@')
        ind_dot=email_id.index('.')
        st=email_id[ind_at+1:ind_dot]
        if(st=="gmail" or st=="yahoo" or st=="hotmail"):
            return True
        else:
            return False
    else:
        return False

def validate_all(name,phone_no,email_id):
    #Start writing your code here
    if(validate_name(name)):
        if(validate_phone_no(phone_no)):
            if(validate_email_id(email_id)):
                print("All the details are valid")
            else:
                print("Invalid email id")
        else:
            print("Invalid phone number")
    else:
        print("Invalid Name")
    # Use the below given print statements to display appropriate messages
    # Also, do not modify them for verification to work
#Provide different values for name, phone_no and email_id and test your program
validate_all("Tina", "9994599998", "tina@yahoo.com")