#USM1-Assgn-15
def check_perfect_number(number):
    if(number==0):
        return False
    else:
        sum=0
        for i in range(1,number):
            if(number%i==0):
                sum=sum+i
        if(sum==number):
            return True
        else:
            return False
    #start writing your code here

def check_perfectno_from_list(no_list):
    #start writing your code here
    perfectno_list=[]
    for i in no_list:
        if(check_perfect_number(i)):
            perfectno_list.append(i)
        else:
            continue
    return (perfectno_list)

perfectno_list=check_perfectno_from_list([12])
print(perfectno_list)