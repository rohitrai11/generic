#USM1-Assgn-9

def encode(message):
    count=1
    encoded=""
    if(len(message)==1):
        encoded+=("1"+message)
    else:
        for i in range(1,len(message)):
            if message[i]==message[i-1]:
                count=count+1
            else:
                encoded+=(str(count)+message[i-1])
                count=1
            if i == len(message)-1:
                encoded+=(str(count)+message[i])
                
                
    return (encoded)

#Provide different values for message and test your program
encoded_message=encode("ABBBBCCCCCCCCAB")
print(encoded_message)