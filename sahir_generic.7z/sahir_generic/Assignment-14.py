#USM1-Assgn-14

def check_anagram(data1,data2):
    data1_list=[]
    data2_list=[]
    
    if(len(data1)!=len(data2)):
        return False
    else:
        data1_list=list(data1.lower())
        data2_list=list(data2.lower())
        for i in range(0,len(data1_list)):
            if(data1_list[i]==data2_list[i]):
                return False
        if(list(set(data1_list)-set(data2_list))==[] and list(set(data2_list)-set(data1_list))==[]):
            return True
        else:
            return False
                           
    #start writing your code here
print(check_anagram("eat","tea"))