#USM1-Assgn-10

def find_common_characters(msg1,msg2):
    length_msg1=len(msg1)
    length_msg2=len(msg2)
    common=""
    common1=''
    for i in range(0,length_msg1):
        for j in range(0,length_msg2):
            if(msg1[i]==msg2[j]):
                if(msg1[i]==" "):
                    continue
                else:
                    common+=msg1[i]
    if(len(common)==0):
        return -1
    else:
        #removing duplicates
        for x in common:
            if not(x in common1):
                common1+=x
            #final string
        return (common1)            

#Provide different values for msg1,msg2 and test your program
msg1="I like Python"
msg2="Java is a very popular language"
common_characters=find_common_characters(msg1,msg2)
print(common_characters)