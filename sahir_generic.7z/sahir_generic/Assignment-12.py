#USM1-Assgn-12
from _overlapped import NULL

def check_double(number):
    double_number=2*number
    number_list=[]
    double_list=[]
    
    if(number==2*number):
        return False
    else:
        while(number!=0):
            rem=number%10
            number_list.append(rem)
            number=number//10
        while(double_number!=0):
            r=double_number%10
            double_list.append(r)
            double_number=double_number//10
    if(list(set(number_list)-set(double_list))==[]):
        return True
    else:
        return False   
    

#Provide different values for number and test your program
print(check_double(125874))