#USM1-Assgn-5
def calculate_bill_amount(food_type,quantity_ordered,distance_in_kms):
    bill_amount=0
#write your logic here
    if(quantity_ordered>=1 and distance_in_kms>0):
        if(food_type=='V'):
            x=120*quantity_ordered
        elif(food_type=='N'):
            x=150*quantity_ordered
        else:
            bill_amount=-1 
        if(distance_in_kms>=6):
            y=9+((distance_in_kms-6)*6)
        elif(distance_in_kms>=3 and distance_in_kms<6):
            y=(distance_in_kms-3)*3
        else:
            y=0 
        if(not(bill_amount==-1)): 
            bill_amount=x+y
    else:
        bill_amount=-1 
    return bill_amount
#Provide different values for food_type,quantity_ordered,distance_in_kms and test your program
bill_amount=calculate_bill_amount("V",2,7)
print(bill_amount)
