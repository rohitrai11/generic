#USM1-Assgn-7
def validate_employee(emp_dict, username, emp_no):
    if emp_no in emp_dict:
        if len(username)>=4:
            if (username[0:3].lower()==emp_dict[emp_no][0:3].lower()) or (username[-3:].lower()==emp_dict[emp_no][-3:].lower()):
                return True
            else:
                return False
        else:
            return False
    else:
        return False
                

emp_dict={1111:'Sim',1234:'James',9999:'Amy',5555:'Jessica'}
username='jess'
emp_no=5555
validate_employee(emp_dict, username, emp_no)