#USM2-Assgn-9

class Apparel:
    counter=100
    def __init__(self,price,item_type):
        Apparel.counter+=1
        self.__item_id=item_type[0]+str(Apparel.counter)
        self.__price=price
        self.__item_type=item_type
    
    def calculate_price(self):
        price=1.05*self.__price
        self.set_price(price)
    
    def get_item_id(self):
        return self.__item_id
    def get_price(self):
        return self.__price
    def get_item_type(self):
        return self.__item_type
    def set_price(self,price):
        self.__price=price
        
class Cotton(Apparel):
    def __init__(self,price,discount):
        super().__init__(price, "Cotton")
        self.__discount=discount
    
    def calculate_price(self):
        super().calculate_price()
        super().set_price((super().get_price()-(super().get_price()*self.__discount/100))*1.05)
    
    def get_discount(self):
        return self.__discount

class Silk(Apparel):
    def __init__(self,price):
        super().__init__(price, "Silk")
        self.__points=0
    
    def calculate_price(self):
        super().calculate_price()
        if(super().get_price()>10000):
            self.__points=10
        else:
            self.__points=3
        super().set_price(super().get_price()*1.10)
        
    def get_points(self):
        return Silk.__points
    
cott=Cotton(5000,10)
sil=Silk(9500)

print(cott.calculate_price())
print(sil.calculate_price())