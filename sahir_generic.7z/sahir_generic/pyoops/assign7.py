#USM2-Assgn-7
#Start writing your code here
from test.regrtest import DESCRIPTION
class Customer:
    def __init__(self,customer_name):
        self.__customer_name=customer_name
        self.__payment_status=None
        self.__bill=None

    def get_customer_name(self):
        return self.__customer_name

        
    def get_payment_status(self):
        return self.__payment_status

    def pays_bill(self,bill):
        self.__bill=bill
        self.__payment_status="Paid"
        print(self.__customer_name)
        print(self.__bill.get_bill_id())
        print(self.__bill.get_bill_amount())
        
    
class Bill:
    counter=1000
    def __init__(self):
        self.__bill_id=0
        self.__bill_amount=0

    def get_bill_id(self):
        return self.__bill_id

    def get_bill_amount(self):
        return self.__bill_amount
    def generate_bill_amount(self,item_quantity,items):
        Bill.counter+=1
        sum=0
        
        self.__bill_id="B"+str(Bill.counter)
        new={}
        for key,value in item_quantity.items():
            new[str(key.lower())]=item_quantity[key]
        print(new)
            
        for i in range(0,len(items)):
            fg=str(items[i].get_item_id()).lower()
            print(fg)
            if fg in new.keys():
                print(sum)
                sum+=(new[fg])*(items[i].get_price_per_quantity())
                
        self.__bill_amount=sum
            
            
class Item:
    def __init__(self,item_id,description,price_per_quantity):
        self.__item_id=item_id
        self.__description=description
        self.__price_per_quantity=price_per_quantity

    def get_item_id(self):
        return self.__item_id


    def get_description(self):
        return self.__description


    def get_price_per_quantity(self):
        return self.__price_per_quantity

mov=Bill()
mov.generate_bill_amount({"Ir987":3,"IR346":2,"IR123":2,"IR658":4},[Item("IR987","Sunfeast_Marie",100),Item("ir658","KellogsOats",151.0),Item("Ir346","Maggie Noodles",35.75),Item("iR234","Kissan Jam",100),Item("IR123","Nescafe",55.50)])
df=Customer("Rumit")
df.pays_bill(mov)
print(df.get_payment_status())



