#USM2-Assgn-8

class FruitInfo:
    __fruit_name_list=["Apple","Guava","Orange","Grape","Sweet Lime"]
    __fruit_price_list=[200,80,70,110,60]
    @staticmethod
    def get_fruit_price(fruit_name):
        if fruit_name in FruitInfo.__fruit_name_list:
            return FruitInfo.__fruit_price_list[FruitInfo.__fruit_name_list.index(fruit_name)]
        else:
            return -1
    
    @staticmethod
    def get_fruit_name_list():
        return FruitInfo.__fruit_name_list
    @staticmethod
    def get_fruit_price_list():
        return FruitInfo.__fruit_price_list

class Purchase:
    __counter=101
    def __init__(self,customer,fruit_name,quantity):
        self.__customer=customer
        self.__fruit_name=fruit_name
        self.__quantity=quantity
        self.__purchase_id=None
        
        
    def get_purchase_id(self):
        return self.__purchase_id
    def get_customer(self):
        return self.__customer
    def get_quantity(self):
        return self.__quantity
    def calculate_price(self):
        fruit_rate=FruitInfo.get_fruit_price(self.__fruit_name)
        max_rate=max(FruitInfo.get_fruit_price_list())
        min_rate=min(FruitInfo.get_fruit_price_list())
        
        self.__purchase_id="P"+str(Purchase.__counter)
        Purchase.__counter+=1
        
        if(fruit_rate!=-1):
            total_price=fruit_rate*self.__quantity
            if(fruit_rate==max_rate and self.__quantity>1):
                total_price*=0.98
            if(fruit_rate==min_rate and self.__quantity>=5):
                total_price*=0.95
            if(self.__customer.get_cust_type()=="wholesale"):
                total_price*=0.90
            return total_price
                
        else:
            return -1
        
class Customer:
    def __init__(self,customer_name,cust_type):
        self.__customer_name=customer_name
        self.__cust_type=cust_type
    def get_customer_name(self):
        return self.__customer_name
    def get_cust_type(self):
        return self.__cust_type
    
customer=Customer("Sahir","wholesale")
purchase=Purchase(customer,"Apple",2)

print(purchase.calculate_price())
        