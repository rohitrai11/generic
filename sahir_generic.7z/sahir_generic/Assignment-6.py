#USM1-Assgn-6
def sum_more_than_five(number):
#remove pass and write your logic here
    sum=0
    while(number>0):
        s=0
        d=number%10
        if(d>5):
            for i in range(int(d),5,-1):
                s=s+i
        sum=sum+s
        number=number/10
    return sum


num = 8
print(sum_more_than_five(num))