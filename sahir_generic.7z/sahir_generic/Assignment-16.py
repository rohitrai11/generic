#USM1-Assgn-16

def check_prime(number):
    flag=0
    for i in range(2,number):
        if(number%i==0):
            flag=1
            break
    if(flag==1):
        return False
    else:
        return True

def rotations(num):
    num_length=len(str(num))
    num_list=list(str(num))
    rot_list=[]
    prime_list=[]
    count=0
    def shift(l, n):
        return l[n:] + l[:n]
    for i in range(0,num_length):
        rot_list=shift(num_list,i)
        r=0
        for k in rot_list:
            r=r*10+int(k)
        prime_list.append(r)
    return prime_list
def get_circular_prime_count(limit):
    count=0
    counter=1
    for i in range(2,limit):
        list_prime_number=[]
        list_prime_number=rotations(i)
        for k in list_prime_number:
            if (check_prime(k)):
                count+=1
            else:
                count=0
                break
        if(count==len(str(i))):
            counter+=1
        else:
            continue
    return counter

print(get_circular_prime_count(100))