#USM1-Assgn-13
def remove_duplicates(value):
    state=""
    for i in value:
        if not(i in state):
            state+=i
    return state
    
    #start writing your code here

print(remove_duplicates("11223445566666ababzzz@@@123#*#*"))