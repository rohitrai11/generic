#USM1-Assgn-11

def find_max(num1, num2):
    #function for calculating sum of digits
    def sum_of_digits(num):
        sum=0
        while(num!=0):
            r=num%10
            sum=sum+r
            num=num//10
        return sum
    #populating list
    max_num=-1
    sample_list=[]
    possible_result=[]
    # Write your logic here
    if(num1>=num2):
        return -1
    else:
        for i in range(num1,num2+1):
            if((sum_of_digits(i)%3==0)and ((i//100)==0) and (i%5==0)):
                        possible_result.append(i)
    if(len(possible_result)==0):
        return -1
    else:
        max_num=max(possible_result)
        return max_num

#Provide different values for num1 and num2 and test your program.
max_num=find_max(10,100)
print(max_num)