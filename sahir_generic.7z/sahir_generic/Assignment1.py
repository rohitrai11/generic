#USM1-Assgn-1

def calculate_interest(principal,rate_of_interest,time):

    interest=0
    interest=(principal*rate_of_interest*time)/100

    #Start writing your code from here

    #Populate the variable: interest
    #Do not modify the below return statement for verification to work

    return interest

print(calculate_interest(2000,5,5))