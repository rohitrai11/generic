#USM2-Assgn-6
class Multiplex:
    __list_movie_name=["movie1","movie2"]
    __list_total_tickets=[100,60]
    __list_last_seat_number=[None,None]
    __list_ticket_price=[150,200]
    def __init__(self):
        self.__seat_numbers=0
        self.__total_price=0
    def calculate_ticket_price(self,movie_index,number_of_tickets):
        self.__total_price= Multiplex.__list_ticket_price[movie_index]*number_of_tickets
    def check_seat_availability(self,movie_index,number_of_tickets):
        if(Multiplex.__list_total_tickets[movie_index]<number_of_tickets):
            return False
        else:
            return True
    def get_total_price(self):
        return self.__total_price
    def get_seat_numbers(self):
        return self.__seat_numbers
    def book_ticket(self, movie_name, number_of_tickets):
        '''Write the logic to book the given number of tickets for the specified movie.'''
    
        if movie_name=="movie1":
            if self.__list_total_tickets[0]<number_of_tickets:
                return -1
            else:
                m1=self.generate_seat_number(0, number_of_tickets)
                self.__seat_numbers=m1
                self.__total_price=150*number_of_tickets
                
        elif movie_name=="movie2":

            if self.__list_total_tickets[1]<number_of_tickets:
                return -1
            else:
                m2=self.generate_seat_number(1, number_of_tickets)
                self.__seat_numbers=m2
                self.__total_price=200*number_of_tickets
        else:return self.__total_price
        
    def  generate_seat_number(self,movie_index, number_of_tickets):
        '''Write the logic to generate and return the list of seat numbers'''
        l1=[]
        l2=[]
        l=[]
        
        
        for i in range(0,number_of_tickets):
            
            if movie_index==0:
                #print("came")
                if self.__list_last_seat_number[0]==None:
                    self.__list_last_seat_number[0]=0
                seat="M1-"
                st=str(self.__list_last_seat_number[0])
                if st.startswith("M1-"):
                    n=st.split("-")
                    self.__list_last_seat_number[0]=int(n[1])
                self.__list_last_seat_number[0]+=1
                self.__list_total_tickets[0]-=1
                seat=seat+str(self.__list_last_seat_number[0])
                l1.append(seat)
                l=l1
            elif movie_index==1:
                if self.__list_last_seat_number[1]==None:
                    self.__list_last_seat_number[1]=0
                seat="M2-"
                st=str(self.__list_last_seat_number[1])
                if st.startswith("M2-"):
                    n=st.split("-")
                    self.__list_last_seat_number[1]=int(n[1])
                
                
                
                self.__list_last_seat_number[1]+=1
                self.__list_total_tickets[1]-=1
                seat=seat+str(self.__list_last_seat_number[1])
                l2.append(seat)
                l=l2
                #print(seat)
            else:pass
        
        return l
booking1=Multiplex()
status=booking1.book_ticket("movie1",5)
if(status==0):
    print("invalid movie name")
elif(status==-1):
    print("Tickets not available for movie-1")
else:
    print("Booking successful")
    print("Seat Numbers :", booking1.get_seat_numbers())
    print("Total amount to be paid:", booking1.get_total_price())
print("-----------------------------------------------------------------------------")
booking2=Multiplex()
status=booking2.book_ticket("movie2",9)
if(status==0):
    print("invalid movie name")
elif(status==-1):
    print("Tickets not available for movie-2")
else:
    print("Booking successful")
    print("Seat Numbers :", booking2.get_seat_numbers())
    print("Total amount to be paid:", booking2.get_total_price())