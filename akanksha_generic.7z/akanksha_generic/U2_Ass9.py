#USM2-Assgn-9
#Start writing your code here
class Apparel:
    counter=100
    def __init__(self,price,item_type):
        self.__item_id=None
        self.__price=price
        self.__item_type=item_type
        if self.__item_type=="Cotton":
            Apparel.counter+=1
            self.__item_id="C"+str(Apparel.counter)
        elif self.__item_type=="Silk":
            Apparel.counter+=1
            self.__item_id="S"+str(Apparel.counter)
        else:pass
        
    def calculate_price(self):
        self.__price=self.get_price()+(self.get_price()*0.05)

    def get_price(self):
        return self.__price


    def get_item_type(self):
        return self.__item_type


    def get_item_id(self):
        return self.__item_id


    def set_price(self, price):
        self.__price = price
 
class Cotton(Apparel):
    def __init__(self,price,discount):
        super().__init__(price, "Cotton")
        self.__discount=discount 

    def get_discount(self):
        return self.__discount

    def calculate_price(self):
        super().calculate_price()
        p=self.get_price()
        p=p-(p*self.get_discount()/100)
        p=p+p*0.05
        self.set_price(p)
        print(self.get_price())
#         self.set_price(p)
#         return self.get_price()
        
class Silk(Apparel):
    def __init__(self,price):
        self.__points=0
        super().__init__(price, "Silk")
        
    def calculate_price(self):
        super().calculate_price()
        q=self.get_price()
        if q>10000:
            self.__points+=10
        else:self.__points+=3
        q=q+q*0.10
        self.set_price(q)
        print(self.get_price())
#         return self.get_price()
    
    def get_points(self):
        return self.__points
        
c=Cotton(8000,2)
s=Silk(10230)
(c.calculate_price())
(s.calculate_price())

    