#USM1-Assgn-14
def check_anagram(data1,data2):
    #start writing your code here
    if len(data1)==len(data2):
        for i in range(len(data1)):
            if data1[i].lower() in data2.lower() and data1[i]!=data2[i] and data2[i].lower() in data1.lower():
                i+=1
            else:
                return False
        return True
    return False

print(check_anagram("Moonstarrer","Astronomer"))