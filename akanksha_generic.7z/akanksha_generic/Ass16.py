#USM1-Assgn-16

def check_prime(number):
    count=0
    prime=False
    for i in range(1,number+1):
        if number%i==0:
            count+=1
    if count==2:
        prime=True
    return prime
    #remove pass and write your logic here. if the number is prime return true, else return false
import math
def rotations(num):
    n=num
    list=[num]
    res=False
    c=0
    no=0
    first=0
    while n>0:
        d=n%10
        n=n//10
        c+=1
        no+=1
        first=d
    while c>1:
        pro=num*10
        new=pro+first
        newno=int(new-(first*math.pow(10, no)))
        list.append(newno)
        num=newno
        c-=1
    return list
    #remove pass and write your logic here. It should return the list of different combinations of digits of the given number.
    #Rotation should be done in clockwise direction. For example, if the given number is 197, the list returned should be [197, 971, 719]

def get_circular_prime_count(limit):
    count=0
    for i in range(1,limit):
        l=[]
        oo=rotations(i)
        for j in oo:
            t=check_prime(j)
            l.append(t)
        if not(False in l):
            count+=1
    return count
     #remove pass and write your logic here.It should return the count of circular prime numbers below the given limit.

#Provide different values for limit and test your program
print(get_circular_prime_count(100))