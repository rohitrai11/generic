class A:
    def m1(self):
        print(1)
        
class B(A):
    def m1(self):
        super().m1()
        print(2)
        
b=B()
b.m1()