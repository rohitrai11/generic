#USM2-Assgn-3
class Customer:
    def __init__(self):
        self.customer_name=None
        self.bill_amount=0
    def pays_bill(self,amount):
        print(self.customer_name+" pays bill amount of Rs."+str(int(amount)))
    def purchases(self):
        self.bill_amount-=self.bill_amount*5/100
        self.pays_bill(self.bill_amount)
c=Customer()
c.customer_name="Raj"
c.bill_amount=1000
c.purchases()
# c.customer_name="Riya"
# c.bill_amount=5500
# c.purchases()        