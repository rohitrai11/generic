#USM1-Assgn-7
def validate_employee(emp_dict, username, emp_no):
#remove pass and write your logic here
    result=False
    if emp_no in emp_dict:
        if len(username)>=4:
            for i in emp_dict.values():
                character=0
                c=i.lower()
                s=''
                uf=''
                ul=''
                for j in c:
                    character+=1
                    if character<=3:
                        s=s+j
                    else:break
                c1=0
                for j in username:
                    c1+=1
                    if c1<=3:
                        uf=uf+j
                    else:break
                c2=len(username)
                for j in range(len(username)):
                    c2-=1
                    if c2>=len(username)-3:
                        ul=ul+username[len(username)-3+j]
                    else:break
                #print(ul)
                if s==uf or s==ul:
                    result=True
    return result
emp_dict={101:'Mike',102:'Tom',103:'Harry'}
username='123tom'
emp_no=102
print(validate_employee(emp_dict, username, emp_no))