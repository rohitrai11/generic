#USM2-Assgn-4
#Start writing your code here
class Flower:
    def __init__(self):
        self.__flower_name=None
        self.__price_per_kg=None
        self.__stock_available=None

    def get_flower_name(self):
        return self.__flower_name


    def get_price_per_kg(self):
        return self.__price_per_kg


    def get_stock_available(self):
        return self.__stock_available


    def set_flower_name(self, value):
        self.__flower_name = value


    def set_price_per_kg(self, value):
        self.__price_per_kg = value


    def set_stock_available(self, value):
        self.__stock_available = value

         
    def validate_flower(self):
        if self.__flower_name.lower()=="orchid" or self.__flower_name.lower()=="rose" or self.__flower_name.lower()=="jasmine":
            return True
        else:
            return False
    
    def validate_stock(self,required_quantity):
        if self.__stock_available>=required_quantity:
            return True
        return False
    
    def sell_flower(self,required_quantity):
        name=self.get_flower_name()
        stock=self.get_stock_available()
        val_name=self.validate_flower()
        val_stock=self.validate_stock(required_quantity)
        if val_name==True and val_stock==True:
            self.__stock_available-=required_quantity
        
    def check_level(self):
        name=self.get_flower_name()
        order_level=0
        if name.lower()=='orchid':
            order_level=15
        elif name.lower()=='rose':
            order_level=25
        elif name.lower()=='jasmine':
            order_level=40
        else:pass
        if self.__stock_available<order_level:
            return True
        else:return False
f=Flower()
f.set_flower_name("rose")
f.set_price_per_kg(20)
f.set_stock_available(30)
print(f.validate_flower())
print(f.validate_stock(24))
f.sell_flower(24)
print(f.check_level())