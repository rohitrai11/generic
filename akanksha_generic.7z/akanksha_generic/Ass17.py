#USM1-Assgn-17
#from curses.ascii import isdigit
def validate_name(name):
    #Start writing your code here
    nam=False
    if name!='' and len(name)<=15:
        if (name.isalpha()):
            nam=True
    return nam

def validate_phone_no(phno):
    #Start writing your code here
    phone=False
    if len(phno)==10 and phno.isdigit():
        for i in phno:
            if phno.count(i)!=10:
                phone=True
    return phone

def validate_email_id(email_id):
    #Start writing your code here
    mail=False
    l=email_id.split('@')
    #print(l)
    if l[0].isalnum and len(l)==2 and '.com' not in l[0]:
        if email_id.endswith('.com'):
            if '@gmail' in email_id or '@yahoo' in email_id or '@hotmail' in email_id:
                mail=True
    return mail

def validate_all(name,phone_no,email_id):
    #Start writing your code here
    # Use the below given print statements to display appropriate messages
    # Also, do not modify them for verification to work
    nam=validate_name(name)
    if nam==False:print("Invalid Name")
    phone=validate_phone_no(phone_no)
    if phone==False:print("Invalid phone number")
    mail=validate_email_id(email_id)
    if mail==False:print("Invalid email id")
    if nam==True and phone==True and mail==True:print("All the details are valid")


#Provide different values for name, phone_no and email_id and test your program
validate_all("Tina", "9994599998", "tina@yahoo.com")