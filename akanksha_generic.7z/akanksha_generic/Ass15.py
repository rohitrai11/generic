#USM1-Assgn-15
def check_perfect_number(number):
    #start writing your code here
    sum=0
    result=0
    for i in range(1,number):
        if number%i==0:
            sum=sum+i
    if sum==number:
        result=1
    return result
        

def check_perfectno_from_list(no_list):
    #start writing your code here
    perfect=[]
    for i in no_list:
        result=check_perfect_number(i)
        if result==1 and i!=0:
            perfect.append(i)
    return perfect

perfectno_list=check_perfectno_from_list([87,76,567,99,0])
print(perfectno_list)