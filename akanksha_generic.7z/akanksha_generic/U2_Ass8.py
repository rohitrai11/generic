#USM2-Assgn-8
#Start writing your code here

class FruitInfo:
    __fruit_name_list=['Apple','Guava','Orange','Grape','Sweet Lime']
    __fruit_price_list=[200,800,70,110,60]
    
    @staticmethod
    def get_fruit_name_list():
        return FruitInfo.__fruit_name_list

    @staticmethod
    def get_fruit_price_list():
        return FruitInfo.__fruit_price_list

    @staticmethod
    def get_fruit_price(fruit_name):
        o=-1
        for i in range(len(FruitInfo.get_fruit_name_list())):
            if fruit_name==FruitInfo.__fruit_name_list[i]:
                o=FruitInfo.__fruit_price_list[i]
        return o


class Purchase:
    __counter=101
    def __init__(self,customer,fruit_name,quantity):
        self.__purchase_id=None
        self.__customer=customer
        self.__fruit_name=fruit_name
        self.__quantity=quantity

    def get_purchase_id(self):
        return self.__purchase_id


    def get_customer(self):
        return self.__customer


    def get_quantity(self):
        return self.__quantity

    def calculate_price(self):
        
        self.__purchase_id='P'+str(Purchase.__counter)
        print(self.__purchase_id)
        Purchase.__counter+=1
        
        if self.__fruit_name in FruitInfo.get_fruit_name_list():
            price=(FruitInfo.get_fruit_price(self.__fruit_name))
            total_fruit_price=self.get_quantity()*price
            
            maxi=price
            price_list=FruitInfo.get_fruit_price_list()
            for i in range(len(price_list)):
                if price_list[i]>maxi:
                    maxi=price_list[i]
            if maxi==price and self.get_quantity()>1:
                total_fruit_price=total_fruit_price-(total_fruit_price*2/100)
                
                
            mini=price
            list_price=FruitInfo.get_fruit_price_list()
            for i in range(len(list_price)):
                if list_price[i]<mini:
                    mini=list_price[i]
            if mini==price and self.get_quantity()>=5:
                total_fruit_price=total_fruit_price-(total_fruit_price*5/100)
               
                
            if self.get_customer()=="wholesale":
                total_fruit_price1=total_fruit_price-(total_fruit_price*10/100)
                
            else:total_fruit_price1=total_fruit_price
                
            
            return total_fruit_price1
        else:
            return -1
        
    
class Customer:
    def __init__(self,customer_name,cust_type):
        self.__customer_name=customer_name
        self.__cust_type=cust_type

    def get_customer_name(self):
        return self.__customer_name


    def get_cust_type(self):
        return self.__cust_type


c=Customer("Tom","wholesale")
p=Purchase(c.get_cust_type(),"Orange",4)
print(p.calculate_price())
    