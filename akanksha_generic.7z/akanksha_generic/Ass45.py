#USM2-Exer-5
#Start writing your code here
class Vehicle:
    def __init__(self,initial_fuel,fuel_left,mileage):
        self.mileage=mileage
        self.initial_fuel=initial_fuel
        self.fuel_left=fuel_left
    def identify_distance_that_can_be_travelled(self):
        distance=0
        if self.fuel_left>5:
            distance=(self.fuel_left-5)*self.mileage
        return distance
    def identify_distance_travelled(self):
        distance=(self.initial_fuel-self.fuel_left)*self.mileage
        return distance
v=Vehicle(25,15,10)
print(v.identify_distance_that_can_be_travelled())
#print(v.identify_distance_travelled())