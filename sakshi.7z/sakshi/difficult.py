def bla(list1):
    list2=[]
    for i in range(0,len(list1)):
        if(i+1<len(list1)):
            x=list1[i+1]-list1[i]
            list2.append(x)
            
    print(list2)
    return list2
 
def blabla(list2):
    count=0
    max1=max(list4)
    list3=[]
    list5=[]
    for j in range(0,len(list1)):
        if list1[j]%max1==0:
            count=count+1
    if count==len(list1):
        for i in range(0,len(list2)):
            if (list2[i]==max1):
                q=list2.index(max1)
                list3.append(str(list1[q+1])+","+str(list1[q]))
                list5.append(list1[q+1]+list1[q])
                list2[q]=-1            
        print(list5)
        max2=max(list5)
        y=list5.index(max2)
        u=list3[y]
        print(u)
       
    else:
        list4.pop(list4.index(max(list4)))
        blabla(list2)
        max1=max(list4)
 
 
list1=[3,6,9,15]
list2=bla(list1)
list4=[]
for k in range(0,len(list2)):
    list4.append(list2[k])
max1=max(list2)
blabla(list2)